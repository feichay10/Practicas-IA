# Informed-Search
This repository contains the implementation of the second practice of the artificial inteligence subject at the University of La Laguna.

## Group components:
 * Name: Cheuk Kelly Ng Pante.
e-mail: alu0101364544@ull.edu.es
* Name: Samuel Martín Morales.
e-mail: alu0101359526@ull.edu.es
